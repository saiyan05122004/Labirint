﻿namespace labirint
{
    public class LabyrinthBatsaev
    {
        private int numLevels;//общее количество уровней
        private int obstaclesPerLevel;// количество препятствий, добавляемых на каждом уровне лабиринта 
        private int basePoints;//базовое количестве очков, назначенных за прохождение лабиринта


        public LabyrinthBatsaev(int numLevels, int obstaclesPerLevel, int basePoints)
        {
            this.numLevels = numLevels; //присваеваем полю его значение 
            this.obstaclesPerLevel = obstaclesPerLevel; //присваеваем полю его значение 
            this.basePoints = basePoints; //присваеваем полю его значение 
        }


        /*CalculateObstacles вычисляет общее количество препятствий
        *для этого уровня путем умножения obstaclesPerLevelна level*/
        public int CalculateObstacles(int level)
        {
            return obstaclesPerLevel * level;/*возвращает вычисленное значение количества препятствий 
                                              * на заданном уровне лабиринта*/
        }


        /*вычисляет общее количество баллов для этого уровня. Количество очков зависит от basePoints, 
        *, numLevels, level и общего количества препятствий для этого уровня.*/
        public int CalculatePoints(int level)
        {
            int totalObstacles = CalculateObstacles(level); /*используется для получения количества препятствий
                 * на заданном уровне лабиринта и сохранения его в переменной totalObstacles для дальнейшего использования*/
           
            
            return basePoints * (numLevels - level + 1) - totalObstacles;
            /*Возвращаемое значение этого оператора будет использоваться для вывода информации о количестве очков на
            * заданном уровне лабиринта.*/
        }
    }

}